import AddTimeTable from "./AddTimeTable";

export default AddTimeTable;
